
# Task Manager PWA

A ready-to-deploy **Task Manager Progressive Web App** with push notification backend.

## 🚀 1-Click Deployment

### 1️⃣ Deploy Backend (Push Server)
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/ShivamSuhane/Task-management)

### 2️⃣ Deploy Frontend (PWA)
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/ShivamSuhane/Task-management)

---

### 📖 Instructions

1. **Deploy to Render** → login → Render creates your backend server → copy the HTTPS URL.
2. **Deploy to Netlify** → login → when asked, add environment variable `BACKEND_URL` = (your Render backend URL).
3. After deployment, open the Netlify URL → tap "Add to Home Screen" on Android → you now have a native-like task manager with real push notifications.
