// Simple front-end placeholder
document.getElementById('app').innerHTML = '<h1>Task Manager PWA</h1><p>Deploy backend first, then this PWA will connect automatically.</p>';
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js');
}