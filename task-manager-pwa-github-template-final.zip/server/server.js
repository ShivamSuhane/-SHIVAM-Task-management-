const express = require('express');
const webpush = require('web-push');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

const vapidKeys = webpush.generateVAPIDKeys();
webpush.setVapidDetails('mailto:example@yourdomain.org', vapidKeys.publicKey, vapidKeys.privateKey);

let subscriptions = [];

app.get('/vapidPublicKey', (req, res) => {
  res.json({ publicKey: vapidKeys.publicKey });
});

app.post('/subscribe', (req, res) => {
  subscriptions.push(req.body);
  res.sendStatus(201);
});

app.post('/notify', async (req, res) => {
  const payload = JSON.stringify({ title: 'Task Reminder', body: req.body.message });
  await Promise.all(subscriptions.map(sub => webpush.sendNotification(sub, payload).catch(()=>{})));
  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server running on port ' + PORT));